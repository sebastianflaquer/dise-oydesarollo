/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practico0;

import java.util.Scanner;
import solucion.SolucionPractico0;

/**
 *
 * @author docenteFI
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        SolucionPractico0_Ejercicio1();
        
    }

    private static void SolucionPractico0_Ejercicio1() {
        
        SolucionPractico0 p0 = new SolucionPractico0();
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ingresar cantidad de numeros: ");
        
        Integer limite = sc.nextInt();
        
        System.out.println("Ingresar los numeros: ");
        
        Integer count = 0;
        
        while(count < limite)
        {
            p0.add(sc.nextDouble());
            count++;
        }
        
        System.out.print("Promedio: ");
        System.out.println(p0.Promedio());
        
        System.out.print("Pares: ");
        System.out.println(p0.Pares());
        
        System.out.print("Multiplos de 3: ");
        System.out.println(p0.Multiplos3());
    }
    
}
