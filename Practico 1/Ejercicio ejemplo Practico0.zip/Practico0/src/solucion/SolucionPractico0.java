/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucion;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author docenteFI
 */
public class SolucionPractico0 {

    private List<Double> lista;
    
    public SolucionPractico0() {
     
        this.lista = new ArrayList<>();
    }
    
    public void add(Double x){
        this.lista.add(x);
    }
    
    public Double Promedio()
    {
        Double total = 0D;
        
        for (Double n:this.lista) {
            total += n;
        }
        
        return total / this.lista.size();
    }
    
    public Integer Pares()
    {
        Integer cantidad = 0;
        
        for (int i = 0; i < this.lista.size(); i++) {
            if (this.lista.get(i) % 2 == 0) {
                cantidad ++;
            }
        }
        
        return cantidad;
    }
    
    public Integer Multiplos3()
    {
        Integer cantidad = 0;
        
        Iterator x = this.lista.iterator();
        
        while(x.hasNext())
        {
            Double aux = Double.parseDouble(
                    x.next().toString());
            
            if (aux % 3 == 0) {
                cantidad ++;
            }
        }
        
        return cantidad;
    }
    
    
}
